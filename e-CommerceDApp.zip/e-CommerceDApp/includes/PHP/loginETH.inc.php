<?php

    session_start(); // si avvia una sessione

    $_SESSION["ETH"] = true; // impostazione delle variabili di sessione (variabili globali)
